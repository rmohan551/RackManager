package com.example.rackmanager

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.util.Log
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.rackmanager.R.layout.activity_main
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.android.parcel.Parcelize
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.parcelize.Parceler
import java.sql.SQLException





@Parcelize
class MainActivity() : AppCompatActivity(), Parcelable {

    var rackId: String = "123"
    var userId: String = "test"
    var bookingDate: String = "DEFAULT"

    private val dbHelper = DBHelper()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(activity_main)

        FirebaseMessaging.getInstance().isAutoInitEnabled = true

        Class.forName("org.postgresql.Driver")

        val tvRackManager = findViewById<TextView>(R.id.tvRackManager)
        val tvList = findViewById<TextView>(R.id.tvList)

        val cbMGU = findViewById<CheckBox>(R.id.cbMGU)
        val cbIdc = findViewById<CheckBox>(R.id.cbIdc)
        val cbEvo = findViewById<CheckBox>(R.id.Evo)
        val submitButton = findViewById<Button>(R.id.Submit)

        submitButton.setOnClickListener {
              GlobalScope.launch {  }
            try {
                val connection = dbHelper.getConnection()
                connection.close()

                val statement = connection.createStatement()
                val sql =
                    "INSERT INTO rack (rack_id, user_id, book) VALUES ('$rackId', '$userId', CURRENT_DATE)"
                statement.executeUpdate(sql)
                statement.close()

            } catch (e: SQLException) {
                e.printStackTrace()
                // Handle database errors
            }

            val selectedRacks = mutableListOf<String>()

            if (cbMGU.isChecked) {
                selectedRacks.add("MGU")
                Log.d(ContentValues.TAG, "onCreate: User selected MGU")
            }

            if (cbIdc.isChecked) {
                selectedRacks.add("IDC23")
                Log.d(ContentValues.TAG, "onCreate: User selected IDC23")
            }

            if (cbEvo.isChecked) {
                selectedRacks.add("IDC Evo")
                Log.d(ContentValues.TAG, "onCreate: User selected IDC Evo")
            }

            val message = if (selectedRacks.isNotEmpty()) {
                "Selected Racks: ${selectedRacks.joinToString(", ")}"
            } else {
                "No racks selected."
            }

            tvList.text = message

            // Start the SecondActivity
            startActivity(Intent(this, SecondActivity::class.java))
            Log.d(ContentValues.TAG, "onCreate: Second activity started")

            testDatabaseConnection()
        }
    }

    private fun testDatabaseConnection() {
        val dbHelper = DBHelper()
        val connectionTestResult = dbHelper.testConnection()
        if (connectionTestResult) {
            println("Database connection successful.")
        } else {
            println("Database connection failed.")
        }
    }

    companion object : Parceler<MainActivity> {
        override fun MainActivity.write(dest: Parcel, flags: Int) {
            dest.writeString(rackId)
            dest.writeString(userId)
            dest.writeString(bookingDate)
        }

        override fun create(parcel: Parcel): MainActivity {
            return MainActivity(parcel)
        }
    }

    constructor(parcel: Parcel) : this() {
        rackId = parcel.readString() ?: ""
        userId = parcel.readString() ?: ""
        bookingDate = parcel.readString() ?: ""
    }
}
