package com.example.rackmanager

import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.messaging.FirebaseMessaging
import java.util.Date
import java.util.Locale

class SecondActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private lateinit var calendarView: CalendarView
    private lateinit var btnSave: Button

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)

        textView = findViewById(R.id.textView)
        calendarView = findViewById(R.id.calendarView)
        btnSave = findViewById(R.id.btnSave)

        // Set a date selected listener for the CalendarView
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val selectedDate = String.format("%d-%02d-%02d", year, month + 1, dayOfMonth)
            textView.text = "Selected Date: $selectedDate"
        }

        // Set a click listener for the Save button
        btnSave.setOnClickListener {
            val selectedDate = getSelectedDate(calendarView)
            if (selectedDate != null) {
                showToast("Saved Date: $selectedDate")
                // Additional logic for saving and sending notification if needed
            } else {
                showToast("No date selected.")
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun getSelectedDate(calendarView: CalendarView): String? {
        // Get the selected date from the CalendarView
        val selectedDateMillis = calendarView.date
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(selectedDateMillis))
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()


    }

    private fun sendPushNotification(selectedDate: String) {
        // Customize the notification message and title
        val notificationTitle = "Booking for your rack"
        val notificationMessage = "You have a booking for $selectedDate"

        // Subscribe to a topic based on the selected date
        FirebaseMessaging.getInstance().subscribeToTopic(selectedDate)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    showToast("Successfully subscribed to topic: $selectedDate")
                } else {
                    showToast("Failed to subscribe to topic: $selectedDate")
                }
            }
    }
}

