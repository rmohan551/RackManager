/*
package com.example.rackmanager
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path


interface ApiService {


    interface ApiService {
            // Define your API endpoints here
            @GET("your-endpoint")
            fun getData(): Call<YourDataType>

            @POST("your-endpoint")
            fun postData(): Call<YourResponseType>
        }

    }

*/



